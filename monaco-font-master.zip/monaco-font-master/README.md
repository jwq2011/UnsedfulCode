monaco-font
===========

Install Monaco Font on Ubuntu

curl -kL https://raw.github.com/cstrap/monaco-font/master/install-font.sh | bash

Inspired by http://jorrel.blogspot.it/2007/11/monaco-on-ubuntu.html
